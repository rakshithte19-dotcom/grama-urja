package com.gramaUrja

import android.os.Bundle
import android.os.CountDownTimer
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class PumpTimerActivity : AppCompatActivity() {

    private lateinit var spinnerCrop: Spinner
    private lateinit var etAreaAcres: EditText
    private lateinit var btnCalculate: Button
    private lateinit var tvResult: TextView
    private lateinit var tvTimerDisplay: TextView
    private lateinit var btnStartTimer: Button
    private lateinit var btnStopTimer: Button
    private lateinit var progressBarTimer: ProgressBar

    private var countDownTimer: CountDownTimer? = null
    private var totalTimeMs: Long = 0

    private val cropWaterRequirements = mapOf(
        "Paddy / Rice" to 60,
        "Wheat" to 40,
        "Sugarcane" to 90,
        "Cotton" to 45,
        "Vegetables" to 30,
        "Groundnut" to 35,
        "Maize / Corn" to 40,
        "Sunflower" to 35
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pump_timer)

        initViews()
        setupSpinner()

        btnCalculate.setOnClickListener { calculatePumpTime() }
        btnStartTimer.setOnClickListener { startTimer() }
        btnStopTimer.setOnClickListener { stopTimer() }

        btnStartTimer.isEnabled = false
        btnStopTimer.isEnabled = false
    }

    private fun initViews() {
        spinnerCrop = findViewById(R.id.spinnerCrop)
        etAreaAcres = findViewById(R.id.etAreaAcres)
        btnCalculate = findViewById(R.id.btnCalculate)
        tvResult = findViewById(R.id.tvResult)
        tvTimerDisplay = findViewById(R.id.tvTimerDisplay)
        btnStartTimer = findViewById(R.id.btnStartTimer)
        btnStopTimer = findViewById(R.id.btnStopTimer)
        progressBarTimer = findViewById(R.id.progressBarTimer)
    }

    private fun setupSpinner() {
        val cropNames = cropWaterRequirements.keys.toList()
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, cropNames)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerCrop.adapter = adapter
    }

    private fun calculatePumpTime() {
        val area = etAreaAcres.text.toString().toDoubleOrNull()

        if (area == null || area <= 0) {
            Toast.makeText(this, "Enter valid area (e.g. 1.5)", Toast.LENGTH_SHORT).show()
            return
        }

        val selectedCrop = spinnerCrop.selectedItem.toString()
        val minsPerAcre = cropWaterRequirements[selectedCrop] ?: 40
        val totalMins = (minsPerAcre * area).toLong()

        totalTimeMs = totalMins * 60 * 1000

        tvResult.text = "Run pump for $totalMins minutes"
        tvTimerDisplay.text = formatTime(totalTimeMs)

        progressBarTimer.max = totalMins.toInt()
        progressBarTimer.progress = 0

        btnStartTimer.isEnabled = true
    }

    private fun startTimer() {
        if (totalTimeMs <= 0) return

        btnStartTimer.isEnabled = false
        btnStopTimer.isEnabled = true

        countDownTimer = object : CountDownTimer(totalTimeMs, 1000) {
            override fun onTick(ms: Long) {
                tvTimerDisplay.text = formatTime(ms)
                val elapsed = (totalTimeMs - ms) / 60000
                progressBarTimer.progress = elapsed.toInt()
            }

            override fun onFinish() {
                tvTimerDisplay.text = "Done"
                progressBarTimer.progress = progressBarTimer.max
                Toast.makeText(this@PumpTimerActivity, "Pump time complete!", Toast.LENGTH_LONG).show()

                btnStartTimer.isEnabled = true
                btnStopTimer.isEnabled = false
            }
        }.start()
    }

    private fun stopTimer() {
        countDownTimer?.cancel()
        tvTimerDisplay.text = "Stopped"
        btnStartTimer.isEnabled = true
        btnStopTimer.isEnabled = false
    }

    private fun formatTime(ms: Long): String {
        val totalSecs = ms / 1000
        val h = totalSecs / 3600
        val m = (totalSecs % 3600) / 60
        val s = totalSecs % 60
        return "%02d:%02d:%02d".format(h, m, s)
    }

    override fun onDestroy() {
        super.onDestroy()
        countDownTimer?.cancel()
    }
}
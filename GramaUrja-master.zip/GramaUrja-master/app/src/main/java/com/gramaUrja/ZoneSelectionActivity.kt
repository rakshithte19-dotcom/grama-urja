package com.gramaUrja

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.messaging.FirebaseMessaging


class ZoneSelectionActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var etSearch: EditText
    private lateinit var btnSearch: Button

    private val allZones = listOf(
        Zone("Zone_A", "Zone A – Krishnapur"),
        Zone("Zone_B", "Zone B – Gopalpur"),
        Zone("Zone_C", "Zone C – Rampur"),
        Zone("Zone_D", "Zone D – Sitapur"),
        Zone("Zone_E", "Zone E – Devpura"),
        Zone("Zone_F", "Zone F – Hanumanthnagar"),
        Zone("Zone_G", "Zone G – Nandipura"),
        Zone("Zone_H", "Zone H – Venkatapur")
    )

    private var filteredZones = allZones.toMutableList()
    private lateinit var adapter: ZoneAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_zone_selection)

        recyclerView = findViewById(R.id.rvZones)
        etSearch = findViewById(R.id.etSearch)
        btnSearch = findViewById(R.id.btnSearch)

        adapter = ZoneAdapter(filteredZones) { zone -> onZoneSelected(zone) }

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        btnSearch.setOnClickListener {
            val query = etSearch.text.toString().trim().lowercase()

            filteredZones.clear()
            if (query.isEmpty()) {
                filteredZones.addAll(allZones)
            } else {
                filteredZones.addAll(
                    allZones.filter {
                        it.displayName.lowercase().contains(query)
                    }
                )
            }

            adapter.notifyDataSetChanged()
        }
    }

    private fun onZoneSelected(zone: Zone) {
        val prefs = getSharedPreferences("GramaUrjaPrefs", MODE_PRIVATE)
        prefs.edit().putString("selectedZone", zone.id).apply()

        FirebaseMessaging.getInstance().subscribeToTopic(zone.id)

        Toast.makeText(this, "Zone set to ${zone.displayName}", Toast.LENGTH_SHORT).show()
        finish()
    }
}

// ---------------- DATA CLASS ----------------
data class Zone(val id: String, val displayName: String)

// ---------------- ADAPTER ----------------
class ZoneAdapter(
    private val zones: List<Zone>,
    private val onSelect: (Zone) -> Unit
) : RecyclerView.Adapter<ZoneAdapter.ZoneViewHolder>() {

    inner class ZoneViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView = view.findViewById(R.id.tvZoneItem)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ZoneViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_zone, parent, false)
        return ZoneViewHolder(view)
    }

    override fun onBindViewHolder(holder: ZoneViewHolder, position: Int) {
        val zone = zones[position]
        holder.tvName.text = zone.displayName
        holder.itemView.setOnClickListener { onSelect(zone) }
    }

    override fun getItemCount(): Int = zones.size
}
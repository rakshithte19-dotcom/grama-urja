package com.gramaUrja

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import com.google.firebase.database.*

class MainActivity : AppCompatActivity() {

    private lateinit var database: DatabaseReference
    private lateinit var tvZoneName: TextView
    private lateinit var tvPowerStatus: TextView
    private lateinit var tvLastSeen: TextView
    private lateinit var tvFreshness: TextView
    private lateinit var btnPowerOn: Button
    private lateinit var btnPowerOff: Button
    private lateinit var cardStatus: CardView
    private lateinit var ivStatusIcon: ImageView
    private lateinit var btnPumpTimer: Button
    private lateinit var btnChangeZone: Button
    private lateinit var progressBar: ProgressBar

    private var selectedZone: String = "Zone_A"
    private var statusListener: ValueEventListener? = null
    private val handler = Handler(Looper.getMainLooper())
    private var lastUpdateTime: Long = 0

    private val freshnessUpdater = object : Runnable {
        override fun run() {
            updateFreshnessLabel()
            handler.postDelayed(this, 30_000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val prefs = getSharedPreferences("GramaUrjaPrefs", MODE_PRIVATE)
        selectedZone = prefs.getString("selectedZone", "Zone_A") ?: "Zone_A"

        initViews()
        setupFirebase()
        loadZoneStatus()

        btnPowerOn.setOnClickListener { updatePowerStatus("ON") }
        btnPowerOff.setOnClickListener { updatePowerStatus("OFF") }

        btnPumpTimer.setOnClickListener {
            startActivity(Intent(this, PumpTimerActivity::class.java))
        }

        btnChangeZone.setOnClickListener {
            startActivity(Intent(this, ZoneSelectionActivity::class.java))
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            requestPermissions(
                arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),
                100
            )
        }
    }

    private fun initViews() {
        tvZoneName = findViewById(R.id.tvZoneName)
        tvPowerStatus = findViewById(R.id.tvPowerStatus)
        tvLastSeen = findViewById(R.id.tvLastSeen)
        tvFreshness = findViewById(R.id.tvFreshness)
        btnPowerOn = findViewById(R.id.btnPowerOn)
        btnPowerOff = findViewById(R.id.btnPowerOff)
        cardStatus = findViewById(R.id.cardStatus)
        ivStatusIcon = findViewById(R.id.ivStatusIcon)
        btnPumpTimer = findViewById(R.id.btnPumpTimer)
        btnChangeZone = findViewById(R.id.btnChangeZone)
        progressBar = findViewById(R.id.progressBar)

        tvZoneName.text = selectedZone.replace("_", " ")
    }

    private fun setupFirebase() {
        database = FirebaseDatabase.getInstance(
            "https://gramaurja-a78ae-default-rtdb.asia-southeast1.firebasedatabase.app/"
        ).reference
    }

    private fun loadZoneStatus() {
        progressBar.visibility = View.VISIBLE

        statusListener?.let {
            database.child("zones").child(selectedZone).removeEventListener(it)
        }

        statusListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                progressBar.visibility = View.GONE

                if (!snapshot.exists()) {
                    tvFreshness.text = "No data yet"
                    return
                }

                val status = snapshot.child("status").getValue(String::class.java) ?: "UNKNOWN"
                val timestamp = snapshot.child("timestamp").getValue(Long::class.java) ?: 0L

                lastUpdateTime = timestamp
                updateUI(status)
                updateFreshnessLabel()
            }

            override fun onCancelled(error: DatabaseError) {
                progressBar.visibility = View.GONE
                Toast.makeText(this@MainActivity, "Error: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        }

        database.child("zones").child(selectedZone).addValueEventListener(statusListener!!)
    }

    private fun updateUI(status: String) {
        tvPowerStatus.text = "Power is $status"
        val isPowerOn = status == "ON"

        if (isPowerOn) {
            cardStatus.setCardBackgroundColor(
                ContextCompat.getColor(this, R.color.power_on_bg)
            )
            tvPowerStatus.setTextColor(
                ContextCompat.getColor(this, R.color.power_on_text)
            )
            ivStatusIcon.setImageResource(R.drawable.ic_power_on)
            tvLastSeen.text = "✅ Power is available!"
        } else {
            cardStatus.setCardBackgroundColor(
                ContextCompat.getColor(this, R.color.power_off_bg)
            )
            tvPowerStatus.setTextColor(
                ContextCompat.getColor(this, R.color.power_off_text)
            )
            ivStatusIcon.setImageResource(R.drawable.ic_power_off)
            tvLastSeen.text = "❌ Power is currently OFF"
        }
    }

    private fun updateFreshnessLabel() {
        if (lastUpdateTime == 0L) {
            tvFreshness.text = "No data yet"
            return
        }

        val diffMs = System.currentTimeMillis() - lastUpdateTime
        val diffMin = diffMs / 60_000

        tvFreshness.text = when {
            diffMin < 1 -> "Updated just now"
            diffMin < 60 -> "Updated ${diffMin} min ago"
            else -> "Updated ${diffMin / 60} hr ago"
        }
    }

    private fun updatePowerStatus(status: String) {
        val timestamp = System.currentTimeMillis()
        val data = mapOf("status" to status, "timestamp" to timestamp)

        database.child("zones").child(selectedZone).setValue(data)
            .addOnSuccessListener {
                Toast.makeText(this, "Status reported: Power $status", Toast.LENGTH_SHORT).show()

                // 🔔 SHOW NOTIFICATION
                showLocalNotification(status)
            }
            .addOnFailureListener {
                Toast.makeText(this, "Failed to update. Check connection.", Toast.LENGTH_SHORT).show()
            }
    }

    private fun showLocalNotification(status: String) {

        val notificationManager =
            getSystemService(android.content.Context.NOTIFICATION_SERVICE) as android.app.NotificationManager

        val channelId = "power_alerts"

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            val channel = android.app.NotificationChannel(
                channelId,
                "Power Alerts",
                android.app.NotificationManager.IMPORTANCE_HIGH
            )
            notificationManager.createNotificationChannel(channel)
        }

        val notification = androidx.core.app.NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info) // 🔥 FIXED
            .setContentTitle("GramaUrja Alert")
            .setContentText("⚡ Power is $status in your zone")
            .setPriority(androidx.core.app.NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true) // 🔥 FIXED
            .build()

        notificationManager.notify(1, notification)
    }

    override fun onResume() {
        super.onResume()

        val prefs = getSharedPreferences("GramaUrjaPrefs", MODE_PRIVATE)
        val newZone = prefs.getString("selectedZone", "Zone_A") ?: "Zone_A"

        if (newZone != selectedZone) {
            selectedZone = newZone
            tvZoneName.text = selectedZone.replace("_", " ")
            loadZoneStatus()
        }

        handler.post(freshnessUpdater)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(freshnessUpdater)
    }

    override fun onDestroy() {
        super.onDestroy()
        statusListener?.let {
            database.child("zones").child(selectedZone).removeEventListener(it)
        }
    }
}